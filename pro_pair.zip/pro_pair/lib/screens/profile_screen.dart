import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({super.key});

  final String userName = 'John Doe';
  final String userEmail = 'johndoe@example.com';
  final List<String> offeredSkills = ['Java', 'UI/UX'];
  final List<String> wantedSkills = ['Public Speaking', 'Flutter'];
  final String skillLevel = 'Intermediate';
  final String skillType = 'Tech-Oriented';
  final String readiness = 'Moderate – Keep building your portfolio';

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                radius: 42,
                backgroundColor: Colors.deepPurpleAccent,
                child: Icon(Icons.person, size: 40, color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: Text(
                userName,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
            ),
            Center(
              child: Text(
                userEmail,
                style: TextStyle(fontSize: 14, color: Colors.grey.shade400),
              ),
            ),
            const SizedBox(height: 32),
            sectionTitle('Skills I Can Teach', textColor),
            ...offeredSkills.map((skill) => skillItem(skill)),

            const SizedBox(height: 24),
            sectionTitle('Skills I Want to Learn', textColor),
            ...wantedSkills.map((skill) => skillItem(skill)),

            const SizedBox(height: 24),
            sectionTitle('Assessment Summary', textColor),
            infoItem(Icons.code, 'Skill Type', skillType),
            infoItem(Icons.bar_chart, 'Skill Level', skillLevel),
            infoItem(Icons.trending_up, 'Job Market Readiness', readiness),
          ],
        ),
      ),
    );
  }

  Widget sectionTitle(String title, Color color) {
    return Text(
      title,
      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: color),
    );
  }

  Widget skillItem(String skill) {
    return ListTile(
      leading: const Icon(
        Icons.check_circle_outline,
        color: Colors.deepPurpleAccent,
        size: 20,
      ),
      title: Text(skill, style: const TextStyle(fontSize: 14)),
    );
  }

  Widget infoItem(IconData icon, String title, String value) {
    return ListTile(
      leading: Icon(icon, color: Colors.deepPurpleAccent, size: 20),
      title: Text(
        title,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      ),
      subtitle: Text(value, style: const TextStyle(fontSize: 13)),
    );
  }
}
