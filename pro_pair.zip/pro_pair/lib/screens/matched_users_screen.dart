import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chat_screen.dart';

class MatchedUsersScreen extends StatefulWidget {
  const MatchedUsersScreen({super.key});

  @override
  State<MatchedUsersScreen> createState() => _MatchedUsersScreenState();
}

class _MatchedUsersScreenState extends State<MatchedUsersScreen> {
  List<Map<String, dynamic>> matches = [];
  bool isLoading = true;

  Future<void> fetchMatches() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final currentSnapshot =
        await FirebaseFirestore.instance
            .collection('skillswap')
            .where('email', isEqualTo: currentUser.email)
            .get();

    if (currentSnapshot.docs.isEmpty) return;

    final userData = currentSnapshot.docs.first.data();
    final userOffered = userData['offered']?.toLowerCase();
    final userWanted = userData['wanted']?.toLowerCase();

    final allUsers =
        await FirebaseFirestore.instance.collection('skillswap').get();

    matches =
        allUsers.docs
            .where((doc) {
              final data = doc.data();
              if (data['email'] == currentUser.email) return false;

              final otherOffered = data['offered']?.toLowerCase();
              final otherWanted = data['wanted']?.toLowerCase();

              return otherOffered == userWanted && otherWanted == userOffered;
            })
            .map((doc) => doc.data())
            .toList();

    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchMatches();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Matching Learners")),
      body:
          isLoading
              ? const Center(child: CircularProgressIndicator())
              : matches.isEmpty
              ? const Center(child: Text("😕 No matching users found yet."))
              : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: matches.length,
                itemBuilder: (context, index) {
                  final user = matches[index];
                  return Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user['email'] ?? 'Unknown',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Offers: ${user['offered']}",
                            style: const TextStyle(fontSize: 14),
                          ),
                          Text(
                            "Wants: ${user['wanted']}",
                            style: const TextStyle(fontSize: 14),
                          ),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.centerRight,
                            child: ElevatedButton.icon(
                              icon: const Icon(Icons.chat),
                              label: const Text("Chat"),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepPurpleAccent,
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (_) => ChatScreen(
                                          peerEmail: user['email'],
                                        ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
    );
  }
}
