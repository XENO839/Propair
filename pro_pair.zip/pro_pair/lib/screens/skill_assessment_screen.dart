import 'package:flutter/material.dart';
import 'result_screen.dart';

class SkillAssessmentScreen extends StatefulWidget {
  const SkillAssessmentScreen({super.key});

  @override
  State<SkillAssessmentScreen> createState() => _SkillAssessmentScreenState();
}

class _SkillAssessmentScreenState extends State<SkillAssessmentScreen> {
  int currentQuestion = 0;
  int score = 0;

  final List<Map<String, dynamic>> questions = [
    {
      'question': 'What is SQL primarily used for?',
      'options': [
        'Developing mobile apps',
        'Creating websites',
        'Managing databases',
        'Designing graphics',
      ],
      'answer': 'Managing databases',
    },
    {
      'question': 'Which is a version control system?',
      'options': ['Firebase', 'Git', 'Docker', 'Jenkins'],
      'answer': 'Git',
    },
    {
      'question': 'Best way to debug a program?',
      'options': [
        'Print statements',
        'Ignore and run again',
        'Use debugger tool',
        'Close and restart',
      ],
      'answer': 'Use debugger tool',
    },
    {
      'question': 'Flutter is developed by?',
      'options': ['Facebook', 'Microsoft', 'Google', 'Apple'],
      'answer': 'Google',
    },
    {
      'question': 'Which is a frontend framework?',
      'options': ['Laravel', 'React', 'Firebase', 'MySQL'],
      'answer': 'React',
    },
  ];

  void nextQuestion(String selectedOption) {
    if (selectedOption == questions[currentQuestion]['answer']) {
      score++;
    }

    if (currentQuestion < questions.length - 1) {
      setState(() {
        currentQuestion++;
      });
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: score, total: questions.length),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[currentQuestion];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Skill Assessment'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              q['question'],
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 30),
            ...q['options'].map<Widget>(
              (opt) => Container(
                margin: const EdgeInsets.only(bottom: 14),
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.deepPurpleAccent),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () => nextQuestion(opt),
                  child: Text(opt, style: const TextStyle(fontSize: 16)),
                ),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurpleAccent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'Next',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
