import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/theme_provider.dart';
import 'profile_screen.dart';
import 'skill_assessment_screen.dart';
import 'skill_swap_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;
    final textColor = Colors.white;
    final bgColor = Colors.deepPurple;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ProPair Dashboard'),
        automaticallyImplyLeading: false,
        actions: [
          Switch(
            value: isDarkMode,
            onChanged: (val) => themeProvider.toggleTheme(val),
            activeColor: Colors.white,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Welcome, User!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(55),
                backgroundColor: bgColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const SkillAssessmentScreen(),
                  ),
                );
              },
              icon: Icon(Icons.assessment, color: textColor),
              label: Text(
                'Take Skill Assessment',
                style: TextStyle(color: textColor),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(55),
                backgroundColor: bgColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SkillSwapScreen()),
                );
              },
              icon: Icon(Icons.swap_horiz, color: textColor),
              label: Text('Skill Swap', style: TextStyle(color: textColor)),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(55),
                backgroundColor: bgColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ProfileScreen()),
                );
              },
              icon: Icon(Icons.person, color: textColor),
              label: Text('View Profile', style: TextStyle(color: textColor)),
            ),
          ],
        ),
      ),
    );
  }
}
