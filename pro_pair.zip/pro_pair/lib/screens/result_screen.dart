import 'package:flutter/material.dart';
import 'skill_swap_screen.dart';
import '../services/chatgpt_service.dart';

class ResultScreen extends StatefulWidget {
  final int score;
  final int total;

  const ResultScreen({super.key, required this.score, required this.total});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late Future<Map<String, String>> resultFuture;

  @override
  void initState() {
    super.initState();
    resultFuture = fetchFormattedResult(widget.score, widget.total);
  }

  Future<Map<String, String>> fetchFormattedResult(int score, int total) async {
    final prompt = '''
I scored $score out of $total in a skill readiness quiz.

Please respond in this format using new lines:

Skill Type: [one line]
Skill Level: [one line]
Job Market Readiness: [short sentence + suggest 2-3 relevant job titles or career paths]
Suggested Skill to Learn: [one programming language or tool I should learn next]
Suggestions: [short paragraph with advice]

No extra words, headings, or new lines. Use colon format.
''';

    final raw = await ChatGPTService.generateResultFromGPT(prompt);
    final lines = raw.split('\n');

    final Map<String, String> resultMap = {
      'Skill Type': 'N/A',
      'Skill Level': 'N/A',
      'Job Market Readiness': 'N/A',
      'Suggested Skill to Learn': 'N/A',
      'Suggestions': 'N/A',
    };

    for (var line in lines) {
      if (line.contains(':')) {
        final parts = line.split(':');
        final key = parts[0].trim();
        final value = parts.sublist(1).join(':').trim();
        if (resultMap.containsKey(key)) {
          resultMap[key] = value;
        }
      }
    }

    return resultMap;
  }

  @override
  Widget build(BuildContext context) {
    double percent = (widget.score / widget.total) * 100;

    return Scaffold(
      appBar: AppBar(title: const Text('Assessment Result')),
      body: FutureBuilder<Map<String, String>>(
        future: resultFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.hasError) {
            return const Center(child: Text('Error fetching result'));
          }

          final result = snapshot.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      height: 140,
                      width: 140,
                      child: CircularProgressIndicator(
                        value: percent / 100,
                        strokeWidth: 10,
                        valueColor: AlwaysStoppedAnimation(
                          Colors.deepPurpleAccent,
                        ),
                        backgroundColor: Colors.grey.shade800,
                      ),
                    ),
                    Text(
                      "${percent.toStringAsFixed(0)}%",
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                buildCard('🧠 Skill Type', result['Skill Type']!),
                buildCard('📊 Skill Level', result['Skill Level']!),
                buildCard(
                  '🔥 Readiness & Careers',
                  result['Job Market Readiness']!,
                ),
                buildCard('🚀 Learn Next', result['Suggested Skill to Learn']!),
                buildCard('💡 Suggestions', result['Suggestions']!),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  icon: const Icon(Icons.group),
                  label: const Text("Find a Peer to Learn With"),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const SkillSwapScreen(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurpleAccent,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("← Back to Dashboard"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget buildCard(String title, String value) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.deepPurpleAccent, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurpleAccent,
            ),
          ),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 14, height: 1.4)),
        ],
      ),
    );
  }
}
