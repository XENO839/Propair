import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../widgets/certificate_upload_widget.dart';
import 'matched_users_screen.dart';

class SkillSwapScreen extends StatefulWidget {
  const SkillSwapScreen({super.key});

  @override
  State<SkillSwapScreen> createState() => _SkillSwapScreenState();
}

class _SkillSwapScreenState extends State<SkillSwapScreen> {
  final offeredController = TextEditingController();
  final wantedController = TextEditingController();
  String? uploadedFileUrl;

  void onCertificateUploaded(String url) {
    setState(() {
      uploadedFileUrl = url;
    });
  }

  Future<void> saveToFirestore() async {
    final user = FirebaseAuth.instance.currentUser;
    final offered = offeredController.text.trim();
    final wanted = wantedController.text.trim();

    if (user == null ||
        offered.isEmpty ||
        wanted.isEmpty ||
        uploadedFileUrl == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please complete all fields and upload a certificate."),
        ),
      );
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('skillswap').add({
        'email': user.email,
        'offered': offered,
        'wanted': wanted,
        'certificateUrl': uploadedFileUrl,
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Skill info saved to Firestore")),
      );

      offeredController.clear();
      wantedController.clear();
      setState(() => uploadedFileUrl = null);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Firestore Error: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Skill Swap')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "🔧 Skill You Offer",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: offeredController,
              decoration: const InputDecoration(
                hintText: "e.g. Java, UI Design",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "🎯 Skill You Want to Learn",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: wantedController,
              decoration: const InputDecoration(
                hintText: "e.g. Flutter, Public Speaking",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            CertificateUploadWidget(onUploaded: onCertificateUploaded),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: saveToFirestore,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurpleAccent,
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text("Save & Match"),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.group),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const MatchedUsersScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple.shade400,
                minimumSize: const Size.fromHeight(50),
              ),
              label: const Text("View Matching Users"),
            ),
          ],
        ),
      ),
    );
  }
}
