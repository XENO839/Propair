import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatGPTService {
  static const String _apiKey =
      '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';
  static const String _endpoint = 'https://api.openai.com/v1/chat/completions';

  static Future<String> generateResultFromGPT(String prompt) async {
    final response = await http.post(
      Uri.parse(_endpoint),
      headers: {
        'Authorization': 'Bearer $_apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'gpt-3.5-turbo',
        'messages': [
          {
            'role': 'system',
            'content':
                'You are a helpful career advisor who gives skill assessments and job readiness advice based on quiz data.',
          },
          {'role': 'user', 'content': prompt},
        ],
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'].toString();
    } else {
      return 'Failed to get response from ChatGPT: ${response.body}';
    }
  }
}
