import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

class CertificateUploadWidget extends StatefulWidget {
  final Function(String url)? onUploaded; // 👈 Accept callback

  const CertificateUploadWidget({super.key, this.onUploaded});

  @override
  State<CertificateUploadWidget> createState() =>
      _CertificateUploadWidgetState();
}

class _CertificateUploadWidgetState extends State<CertificateUploadWidget> {
  String? uploadedFileName;
  bool isUploading = false;

  Future<void> pickAndUploadFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'png', 'jpg'],
    );

    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final fileName = result.files.single.name;

      setState(() {
        isUploading = true;
        uploadedFileName = fileName;
      });

      try {
        final ref = FirebaseStorage.instance.ref().child(
          'certificates/$fileName',
        );
        await ref.putFile(file);
        final downloadURL = await ref.getDownloadURL();

        if (widget.onUploaded != null) {
          widget.onUploaded!(downloadURL); // 👈 Callback result to parent
        }

        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('✅ Uploaded: $fileName')));
      } catch (e) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Upload Failed: $e')));
      } finally {
        setState(() => isUploading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "📎 Upload Certificate (PDF/Image)",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          onPressed: isUploading ? null : pickAndUploadFile,
          icon: const Icon(Icons.upload_file),
          label: const Text("Upload"),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.deepPurpleAccent,
            minimumSize: const Size.fromHeight(45),
          ),
        ),
        if (uploadedFileName != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              "✅ File: $uploadedFileName",
              style: const TextStyle(fontSize: 14),
            ),
          ),
      ],
    );
  }
}
