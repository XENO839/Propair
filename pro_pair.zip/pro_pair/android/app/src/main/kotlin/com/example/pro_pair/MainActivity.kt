package com.example.pro_pair

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
